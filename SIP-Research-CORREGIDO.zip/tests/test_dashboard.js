const fs = require('fs');
const vm = require('vm');

class FakeEl {
  constructor(id) { this.id = id; this._text=''; this._html=''; this.children=[]; this.style={}; }
  set textContent(v){ this._text = v; }
  get textContent(){ return this._text; }
  set innerHTML(v){ this._html = v; }
  get innerHTML(){ return this._html; }
  appendChild(child){ this.children.push(child); }
}

const registry = {};
['total-estudios','cobertura','regiones','temas','ultimo-anio','lista-regiones','lista-temas','lista-anios'].forEach(id=>{
  registry[id] = new FakeEl(id);
});

const sandbox = {
  document: {
    getElementById(id){
      if(!registry[id]) registry[id] = new FakeEl(id);
      return registry[id];
    },
    createElement(){ return new FakeEl(null); },
    body: new FakeEl('body')
  },
  console
};
sandbox.window = sandbox;
vm.createContext(sandbox);

const path = require('path');
const appDir = path.join(__dirname, '..', 'app');
const files = ['data.js','analisis.js','motor-sip.js','motor-epidemiologico.js'];
for (const f of files) {
  const code = fs.readFileSync(path.join(appDir, f), 'utf8');
  try {
    vm.runInContext(code, sandbox, { filename: f });
    console.log(`[OK] ${f} ejecutado sin errores`);
  } catch (e) {
    console.error(`[FALLA] ${f} ->`, e.message);
    throw e;
  }
}

console.log('---RESULTADOS---');
console.log('total-estudios:', registry['total-estudios'].textContent);
console.log('cobertura:', registry['cobertura'].textContent);
console.log('regiones:', registry['regiones'].textContent);
console.log('temas:', registry['temas'].textContent);
console.log('bloques añadidos al body (motores + informes):', sandbox.document.body.children.length);
